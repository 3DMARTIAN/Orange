function showMessage() {
    alert("Segarnya jeruk! 🍊");
}
