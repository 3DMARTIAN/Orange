# 🍊 Jeruk Website

Project website sederhana bertema jeruk untuk latihan GitHub.

## Fitur
- Tema warna jeruk
- HTML, CSS, JavaScript sederhana
- Tombol interaktif

## Cara Menjalankan
1. Download atau clone repo ini
2. Buka file index.html di browser

## Author
Project latihan GitHub
